package contactservice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddAndGetContact() {
        Contact contact = new Contact("1", "Zac", "H", "0123456789", "123 St");
        service.addContact(contact);
        assertEquals("Zac", service.getContactDetails("1").getFirstName());
    }

    @Test
    public void testDuplicateContactId() {
        Contact contact1 = new Contact("1", "Zac", "H", "0123456789", "123 St");
        Contact contact2 = new Contact("1", "Jane", "D", "9876543210", "456 Rd");

        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("1", "Zac", "H", "0123456789", "123 St");
        service.addContact(contact);
        service.deleteContact("1");
        assertNull(service.getContactDetails("1"));
    }

    @Test
    public void testUpdateFields() {
        Contact contact = new Contact("1", "Zac", "H", "0123456789", "123 St");
        service.addContact(contact);

        service.updateFirstName("1", "John");
        service.updateLastName("1", "Doe");
        service.updatePhone("1", "9876543210");
        service.updateAddress("1", "456 Rd");

        Contact updated = service.getContactDetails("1");
        assertEquals("John", updated.getFirstName());
        assertEquals("Doe", updated.getLastName());
        assertEquals("9876543210", updated.getPhone());
        assertEquals("456 Rd", updated.getAddress());
    }

    @Test
    public void testUpdateInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("999", "John"));
    }
}

