package contactservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("1234567890", "Zac", "Harrington", "0123456789", "123 Space Center Blvd");
        assertEquals("1234567890", contact.getContactId());
        assertEquals("Zac", contact.getFirstName());
        assertEquals("Harrington", contact.getLastName());
        assertEquals("0123456789", contact.getPhone());
        assertEquals("123 Space Center Blvd", contact.getAddress());
    }

    @Test
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Zac", "H", "0123456789", "123 St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Zac", "H", "0123456789", "123 St"));
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Zac", "H", "123", "123 St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Zac", "H", null, "123 St"));
    }

    @Test
    public void testSetters() {
        Contact contact = new Contact("1", "Zac", "H", "0123456789", "123 St");
        contact.setFirstName("John");
        contact.setLastName("Doe");
        contact.setPhone("9876543210");
        contact.setAddress("456 Galaxy Drive");

        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("9876543210", contact.getPhone());
        assertEquals("456 Galaxy Drive", contact.getAddress());
    }
}
